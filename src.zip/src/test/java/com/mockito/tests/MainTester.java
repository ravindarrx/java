package com.mockito.tests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import com.tdd.wordsmith.service.*;
import static org.mockito.Mockito.*;
import com.tdd.wordsmith.domain.*;

public class MainTester {

	/*
	 * 1. create junit
	 * 2. create junit dummy implementation
	 * 3. create mockito
	 * */
	
   WordUploaderService uploader;
   BasicWord input;
   
   @Before
   public void setup(){
	   uploader = new WordUploaderServiceImpl();
   }

   @Test
   public void itShouldReturnSucessUponUpload(){
	  String input = "test";
	  uploader = mock(WordUploaderService.class);
	  //Boolean result = uploader.upload("test");
	  when(uploader.upload(input)).thenReturn(true);
	  boolean result = uploader.upload(input);
	  assertEquals(result,true);
   }
   
   @Test
   public void itShouldAcceptWordObject(){
	   input = new BasicWord("test","easy");
	   uploader = mock(WordUploaderService.class);
	   when(uploader.uploadWord(input)).thenReturn(true);
	   boolean result = uploader.uploadWord(input);
	   assertEquals(result,true);
   }
   
   @Test
   public void itShouldUploadWordToDatabase(){
	   input = new BasicWord("test","easy");
	   uploader = mock(WordUploaderService.class);
	   when(uploader.uploadWordToDatabase(input)).thenReturn(true);
	   boolean result = uploader.uploadWordToDatabase(input);
	   assertEquals(result,true);
   }
   
   @Test
   public void itShouldSetStatusAsUploaded(){
	   input = new BasicWord("test","easy");
	   input.setStatus("uploaded");
	   uploader = new WordUploaderServiceImpl();
	   boolean result = uploader.uploadWordToDatabase(input);
	   assertEquals(result,true);
   }
   
}
