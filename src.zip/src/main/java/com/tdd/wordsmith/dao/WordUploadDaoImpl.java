package com.tdd.wordsmith.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.springframework.stereotype.Repository;

import com.tdd.wordsmith.domain.*;

@Repository ("WordUploadDao")
public class WordUploadDaoImpl implements WordUploadDao {

	// JDBC driver name and database URL
   static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
   static final String DB_URL = "jdbc:mysql://localhost/spellbee";

   //  Database credentials
   static final String USER = "root";
   static final String PASS = "krishna1";
   
	@Override
	public boolean uploadWord(BasicWord word) {
		System.out.println("running query to upload word");
		Connection conn = null;
		PreparedStatement pstmt = null;
		int update_count = 0;
		try
		{
	      Class.forName("com.mysql.jdbc.Driver");
	      System.out.println("Connecting to database...");
	      conn = DriverManager.getConnection(DB_URL,USER,PASS);
	      System.out.println("Creating statement...");
	      pstmt = conn.prepareStatement("INSERT INTO `word`(word_string,difficulty,status) VALUES (?, ?, ?)");
	      pstmt.setString(1, word.getActualWord());
	      pstmt.setString(2, word.getDifficulty());
	      pstmt.setString(3, word.getStatus());
	      update_count = pstmt.executeUpdate();
	   }
	   catch(Exception e)
	   {
	      e.printStackTrace();
	   }
	   finally
	   {
		   try 
		   {
			pstmt.close();
		   } catch (SQLException e)
		   {
			e.printStackTrace();
		   }
		   try 
		   {
			conn.close();
		   } catch (SQLException e) {
			e.printStackTrace();
		   }
	   }
	   if (update_count == 1){
		   return true;
	   }
	   else
	   {
		   return false;
	   }
	   
	}

}
