package com.tdd.wordsmith.dao;

import com.tdd.wordsmith.domain.*;;

public interface WordUploadDao {

	public boolean uploadWord( BasicWord word);
}
