package com.tdd.wordsmith.service;

import com.tdd.wordsmith.domain.BasicWord;

public interface WordUploaderService {

	public Boolean upload(String string);

	public boolean uploadWord(BasicWord input);

	public boolean uploadWordToDatabase(BasicWord input);

}
