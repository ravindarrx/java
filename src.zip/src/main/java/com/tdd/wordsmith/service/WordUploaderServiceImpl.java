package com.tdd.wordsmith.service;

import org.springframework.stereotype.Service;

import com.tdd.wordsmith.domain.BasicWord;
import com.tdd.wordsmith.dao.WordUploadDao;
import com.tdd.wordsmith.dao.WordUploadDaoImpl;

@Service("WordUploaderService")
public class WordUploaderServiceImpl implements WordUploaderService {

	@Override
	public Boolean upload(String string) {
		return true;
	}

	@Override
	public boolean uploadWord(BasicWord input) {
		return true;
	}

	@Override
	public boolean uploadWordToDatabase(BasicWord input) {
		// -- Call the DB stuff to save
		System.out.println(" calling dao ");
		if ( null == input.getStatus())
		{
			input.setStatus("uploaded");
		}
		WordUploadDao wordUploadDao = new WordUploadDaoImpl();
		return wordUploadDao.uploadWord(input);
	}

}
