package com.tdd.wordsmith.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.tdd.wordsmith.domain.BasicWord;
import com.tdd.wordsmith.service.WordUploaderService;
import com.tdd.wordsmith.service.WordUploaderServiceImpl;

@Controller
public class WordUploadController {
	
	
	@Autowired 
	WordUploaderService wordUploaderService = new WordUploaderServiceImpl();

	
	@RequestMapping(value="/wordUpload", method = RequestMethod.GET)
	public @ResponseBody String uploadWord(@RequestParam("actualWord") String actualWord,@RequestParam("difficulty") String difficulty  )
	{
		BasicWord word = new BasicWord();
		word.setActualWord(actualWord);
		word.setDifficulty(difficulty);
		System.out.println("received input actualWord"+actualWord);
		System.out.println("received input difficulty"+difficulty);
		if ( wordUploaderService.uploadWordToDatabase(word))
		{
			return "Word Uploaded !!";
		}
		else
		{
			return "Upload failed !!";
		}
	}
	
/*	public void storeWords(){
		
		
	}*/

}
