package com.tdd.wordsmith.domain;

import java.io.Serializable;

public class BasicWord implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String actualWord;
	
	private String difficulty;
	
	private String status;
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDifficulty() {
		return difficulty;
	}

	public void setDifficulty(String difficulty) {
		this.difficulty = difficulty;
	}

	public String getActualWord() {
		return actualWord;
	}
	
	public BasicWord(String word,String difficulty){
		this.actualWord = word;
		this.difficulty = difficulty;
	}

	public void setActualWord(String actualWord) {
		this.actualWord = actualWord;
	}
	
	public BasicWord(){
		
	}

}